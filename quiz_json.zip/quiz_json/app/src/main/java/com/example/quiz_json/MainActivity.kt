package com.example.quiz_json

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject


// Define a data class to represent a single question
data class Question(val question: String, val answer: Boolean)

// Read the JSON file from assets and parse it into an array of Question objects
fun loadQuestionsFromAssets(context: Context): Array<Question> {
    val jsonString = context.assets.open("quiz_questions.json").bufferedReader().use { it.readText() }
    val json = JSONObject(jsonString)
    val questionsJson = json.getJSONArray("questions")
    Log.d("MainActivity", questionsJson[0].toString())

    val questions = Array(questionsJson.length()) { i ->
        val questionJson = questionsJson.getJSONObject(i)
        Question(questionJson.getString("question"), questionJson.getBoolean("answer"))
    }
    return questions
}

class MainActivity : AppCompatActivity() {

    var count = 0
    var score = 0
    var flag =  true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.quiz_layout)

        val question = findViewById<TextView>(R.id.question)
        val truebutton = findViewById<Button>(R.id.true_button)
        val flasebutton = findViewById<Button>(R.id.false_button)

        // Load the questions from assets
        val questions = loadQuestionsFromAssets(this)

        // Example: print the first question to logcat
        Log.d("MainActivity", questions[0].question)

        Toast.makeText(this, "No.of questions are ${questions.size}", Toast.LENGTH_SHORT).show()

        question.text= questions[count].question

        truebutton.setOnClickListener {
        flag = true
            nextquestion()
        }

        flasebutton.setOnClickListener {
            flag = false
            nextquestion()
        }

    }

    private fun nextquestion() {
        val questions = loadQuestionsFromAssets(this)
        val question = findViewById<TextView>(R.id.question)

        if (count < 9) {

            if (flag == questions[count].answer) {
                score++
                Toast.makeText(this, "correct choice", Toast.LENGTH_SHORT).show()
            }
            else
            {
                Toast.makeText(this, "wrong choice", Toast.LENGTH_SHORT).show()
            }
            count++
            question.text = questions[count].question
        }
        else
        {
            Toast.makeText(this, "Your Score is $score", Toast.LENGTH_SHORT).show()
        }
    }
}
