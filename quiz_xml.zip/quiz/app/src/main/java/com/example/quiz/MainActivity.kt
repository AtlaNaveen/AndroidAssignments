package com.example.quiz

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.View.OnClickListener
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    var count = 0
    var score = 0
    var flag = "true"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.quiz_layout)

        val question = findViewById<TextView>(R.id.question)
        val truebutton = findViewById<Button>(R.id.true_button)
        val flasebutton = findViewById<Button>(R.id.false_button)
        val questions_array = resources.getStringArray(R.array.array_questions)
        val answers_array = resources.getStringArray(R.array.array_answers)

        val size = answers_array.size
        Toast.makeText(this, "No.of questions are $size", Toast.LENGTH_SHORT).show()


        question.text= questions_array[count]

        truebutton.setOnClickListener {
            flag = "true"
            commoncode()
        }

        flasebutton.setOnClickListener {
            flag = "false"
            commoncode()
        }

    }

    private fun commoncode() {
        val question = findViewById<TextView>(R.id.question)
        val answers_array = resources.getStringArray(R.array.array_answers)
        val questions_array = resources.getStringArray(R.array.array_questions)


        if (count < 9) {

            if (flag == answers_array[count]) {
                score++
                Toast.makeText(this, "correct choice", Toast.LENGTH_SHORT).show()
            }
            else
            {
                Toast.makeText(this, "wrong choice", Toast.LENGTH_SHORT).show()
            }
            count++
            question.text = questions_array[count]
        }
        else
        {
            Toast.makeText(this, "Your Score is $score", Toast.LENGTH_SHORT).show()
        }
    }


//        // Design 02
//        class False : OnClickListener {
//            override fun onClick(p0: View?) {
//
//                Toast.makeText(this@MainActivity, "false", Toast.LENGTH_LONG).show()
//
//            }
//        }
//        flasebutton.setOnClickListener(False())
//
//
//        // Design 03
//
//        truebutton.setOnClickListener(object :OnClickListener{
//            override fun onClick(p0: View?) {
//                Toast.makeText(this@MainActivity, "true", Toast.LENGTH_LONG).show()
//            }
//
//        })
//
//
//




}


